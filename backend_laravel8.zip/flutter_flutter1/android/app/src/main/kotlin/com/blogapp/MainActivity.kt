package com.blogapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
