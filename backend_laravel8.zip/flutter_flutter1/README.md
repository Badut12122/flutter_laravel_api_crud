# Flutter Blog App

A Flutter blog application, part of youtube tutorial project.

## Getting Started

This project is developed with Flutter v2.2+ and requires an api

 - clone or fork the repo
 - install required pub packages
 - Edit `constant.dart` file and put your domain address
 - run the app

 The backend (api) is developed with Laravel 8 you can get it [Here](https://github.com/habibmhamadi/laravel8-blog-api)
